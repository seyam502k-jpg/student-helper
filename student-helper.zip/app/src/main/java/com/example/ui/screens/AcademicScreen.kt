package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Functions
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.nctb.NctbChapter
import com.example.data.nctb.NctbContentRepository
import com.example.data.nctb.NctbSubject
import com.example.data.nctb.VideoLesson
import com.example.ui.theme.GoldStar
import com.example.ui.theme.RoyalBluePrimary
import com.example.ui.theme.SuccessGreen

@Composable
fun AcademicScreen(
    selectedClassId: String,
    selectedSubject: NctbSubject?,
    selectedChapter: NctbChapter?,
    selectedVideo: VideoLesson?,
    pdfChapter: NctbChapter?,
    onSelectSubject: (NctbSubject) -> Unit,
    onSelectChapter: (NctbChapter) -> Unit,
    onOpenVideo: (VideoLesson, NctbChapter) -> Unit,
    onCloseVideo: () -> Unit,
    onOpenPdf: (NctbChapter) -> Unit,
    onClosePdf: () -> Unit,
    onStartQuiz: (NctbChapter) -> Unit,
    onSaveDownload: (NctbChapter) -> Unit,
    modifier: Modifier = Modifier
) {
    val currentClass = NctbContentRepository.allClasses.find { it.id == selectedClassId }
        ?: NctbContentRepository.allClasses.first()
    val subjects = currentClass.subjects

    when {
        pdfChapter != null -> {
            PdfReaderView(
                chapter = pdfChapter,
                onClose = onClosePdf,
                onSaveDownload = { onSaveDownload(pdfChapter) }
            )
        }
        selectedVideo != null && selectedChapter != null -> {
            VideoLessonPlayerView(
                video = selectedVideo,
                chapter = selectedChapter,
                onClose = onCloseVideo
            )
        }
        selectedChapter != null -> {
            ChapterDetailView(
                chapter = selectedChapter,
                onBack = { onSelectSubject(selectedSubject ?: subjects.first()) },
                onOpenVideo = { video -> onOpenVideo(video, selectedChapter) },
                onOpenPdf = { onOpenPdf(selectedChapter) },
                onStartQuiz = { onStartQuiz(selectedChapter) },
                onSaveDownload = { onSaveDownload(selectedChapter) }
            )
        }
        else -> {
            SubjectAndChapterListView(
                subjects = subjects,
                selectedSubject = selectedSubject ?: subjects.firstOrNull(),
                onSelectSubject = onSelectSubject,
                onSelectChapter = onSelectChapter
            )
        }
    }
}

@Composable
fun SubjectAndChapterListView(
    subjects: List<NctbSubject>,
    selectedSubject: NctbSubject?,
    onSelectSubject: (NctbSubject) -> Unit,
    onSelectChapter: (NctbChapter) -> Unit
) {
    if (subjects.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            contentAlignment = Alignment.Center
        ) {
            Text("এই শ্রেণির জন্য বিষয়বস্তু খুব শীঘ্রই যোগ করা হবে।", fontSize = 16.sp)
        }
        return
    }

    val activeSubject = selectedSubject ?: subjects.first()

    Column(modifier = Modifier.fillMaxSize()) {
        // Subject Scrollable Tabs
        ScrollableTabRow(
            selectedTabIndex = subjects.indexOf(activeSubject).coerceAtLeast(0),
            edgePadding = 16.dp,
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            subjects.forEach { subject ->
                Tab(
                    selected = subject.id == activeSubject.id,
                    onClick = { onSelectSubject(subject) },
                    text = {
                        Text(
                            text = subject.nameBangla,
                            fontWeight = if (subject.id == activeSubject.id) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 14.sp
                        )
                    }
                )
            }
        }

        // Chapters List
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${activeSubject.nameBangla} - সকল অধ্যায়",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "${activeSubject.chapters.size} টি অধ্যায়",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )
                }
            }

            if (activeSubject.chapters.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 16.dp)
                    ) {
                        Text(
                            text = "অধ্যায়ের শর্ট নোট ও লেসন আপলোড চলছে...",
                            modifier = Modifier.padding(24.dp),
                            fontSize = 14.sp
                        )
                    }
                }
            } else {
                items(activeSubject.chapters) { chapter ->
                    ElevatedCard(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("chapter_card_${chapter.id}")
                            .clickable { onSelectChapter(chapter) }
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    shape = CircleShape,
                                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
                                    modifier = Modifier.size(40.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text(
                                            text = "${chapter.chapterNumber}",
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = chapter.titleBangla,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = chapter.title,
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = chapter.summary,
                                fontSize = 12.sp,
                                maxLines = 2,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                            )
                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "🎥 ${chapter.videoLessons.size} লেসন  |  📝 ${chapter.shortNotes.size} শর্ট নোট",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Button(
                                    onClick = { onSelectChapter(chapter) },
                                    shape = RoundedCornerShape(20.dp),
                                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp)
                                ) {
                                    Text("পড়ুন", fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ChapterDetailView(
    chapter: NctbChapter,
    onBack: () -> Unit,
    onOpenVideo: (VideoLesson) -> Unit,
    onOpenPdf: () -> Unit,
    onStartQuiz: () -> Unit,
    onSaveDownload: () -> Unit
) {
    var activeTab by remember { mutableStateOf(0) } // 0: সারসংক্ষেপ, 1: শর্ট নোট, 2: সূত্র, 3: বোর্ড প্রশ্ন, 4: ভিডিও

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                }
                Text(
                    text = "অধ্যায় ${chapter.chapterNumber}: ${chapter.titleBangla}",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }

        // Action Buttons Row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onOpenPdf,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = RoyalBluePrimary),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(imageVector = Icons.Default.PictureAsPdf, contentDescription = "PDF")
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("PDF Reader", fontSize = 12.sp)
                }

                Button(
                    onClick = onStartQuiz,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(imageVector = Icons.Default.Quiz, contentDescription = "Quiz")
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("কুইজ টেস্ট", fontSize = 12.sp)
                }

                OutlinedButton(
                    onClick = onSaveDownload,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(imageVector = Icons.Default.Download, contentDescription = "Save")
                }
            }
        }

        // Sub Tabs
        item {
            ScrollableTabRow(
                selectedTabIndex = activeTab,
                edgePadding = 0.dp,
                containerColor = Color.Transparent
            ) {
                Tab(selected = activeTab == 0, onClick = { activeTab = 0 }) {
                    Text("সারসংক্ষেপ", modifier = Modifier.padding(12.dp), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
                Tab(selected = activeTab == 1, onClick = { activeTab = 1 }) {
                    Text("শর্ট নোট", modifier = Modifier.padding(12.dp), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
                Tab(selected = activeTab == 2, onClick = { activeTab = 2 }) {
                    Text("সূত্রসমূহ", modifier = Modifier.padding(12.dp), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
                Tab(selected = activeTab == 3, onClick = { activeTab = 3 }) {
                    Text("বোর্ড প্রশ্ন", modifier = Modifier.padding(12.dp), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
                Tab(selected = activeTab == 4, onClick = { activeTab = 4 }) {
                    Text("ভিডিও ক্লাস", modifier = Modifier.padding(12.dp), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        when (activeTab) {
            0 -> item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("📖 অধ্যায়ের সারসংক্ষেপ", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(chapter.summary, fontSize = 14.sp, lineHeight = 22.sp)
                    }
                }
            }
            1 -> items(chapter.shortNotes) { note ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(modifier = Modifier.padding(14.dp)) {
                        Text("📌", fontSize = 16.sp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(note, fontSize = 13.sp, lineHeight = 20.sp)
                    }
                }
            }
            2 -> items(chapter.formulas) { formula ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Functions, contentDescription = "Formula", tint = RoyalBluePrimary)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(formula, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    }
                }
            }
            3 -> items(chapter.boardQuestions) { boardQ ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(boardQ, fontSize = 13.sp, lineHeight = 20.sp)
                    }
                }
            }
            4 -> items(chapter.videoLessons) { video ->
                ElevatedCard(
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onOpenVideo(video) }
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(imageVector = Icons.Default.PlayArrow, contentDescription = "Play", tint = Color.White)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(video.title, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            Text("শিক্ষক: ${video.teacherName} • ${video.durationMinutes} মিনিট", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun VideoLessonPlayerView(
    video: VideoLesson,
    chapter: NctbChapter,
    onClose: () -> Unit
) {
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onClose) {
                Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
            }
            Text("ভিডিও লেসন: ${video.title}", fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Embedded Player Simulation Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(Color.Black),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = "Play Video",
                    tint = Color.White,
                    modifier = Modifier.size(64.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "${video.teacherName} (Duration: ${video.durationMinutes} min)",
                    color = Color.White,
                    fontSize = 13.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(text = video.title, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Text(text = "অধ্যায়: ${chapter.titleBangla}", fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)

        Spacer(modifier = Modifier.height(24.dp))

        Text(text = "ইউটিউব লিংকে সরাসরি দেখতে ক্লিক করুন:", fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Button(
                onClick = {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=${video.youtubeVideoId}"))
                    context.startActivity(intent)
                },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF0000))
            ) {
                Text("Open YouTube App")
            }

            OutlinedButton(
                onClick = {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=${video.youtubeVideoId}"))
                    context.startActivity(intent)
                },
                modifier = Modifier.weight(1f)
            ) {
                Icon(imageVector = Icons.Default.OpenInBrowser, contentDescription = "Browser")
                Spacer(modifier = Modifier.width(4.dp))
                Text("Browser")
            }
        }
    }
}

@Composable
fun PdfReaderView(
    chapter: NctbChapter,
    onClose: () -> Unit,
    onSaveDownload: () -> Unit
) {
    var zoomScale by remember { mutableFloatStateOf(1.0f) }
    var searchQuery by remember { mutableStateOf("") }
    var isBookmarked by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF212121))
    ) {
        // PDF Toolbar
        Surface(
            color = Color(0xFF333333),
            contentColor = Color.White
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onClose) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Close PDF", tint = Color.White)
                    }
                    Text(
                        text = "PDF: ${chapter.titleBangla}",
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1
                    )
                }

                Row {
                    IconButton(onClick = { if (zoomScale > 0.8f) zoomScale -= 0.2f }) {
                        Icon(imageVector = Icons.Default.ZoomOut, contentDescription = "Zoom Out", tint = Color.White)
                    }
                    IconButton(onClick = { if (zoomScale < 2.0f) zoomScale += 0.2f }) {
                        Icon(imageVector = Icons.Default.ZoomIn, contentDescription = "Zoom In", tint = Color.White)
                    }
                    IconButton(onClick = { isBookmarked = !isBookmarked }) {
                        Icon(
                            imageVector = if (isBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                            contentDescription = "Bookmark",
                            tint = GoldStar
                        )
                    }
                    IconButton(onClick = onSaveDownload) {
                        Icon(imageVector = Icons.Default.Download, contentDescription = "Download", tint = Color.White)
                    }
                }
            }
        }

        // PDF Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("PDF এর মধ্যে খুঁজুন...", color = Color.Gray, fontSize = 12.sp) },
            leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = "Search", tint = Color.Gray) },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            shape = RoundedCornerShape(20.dp)
        )

        // PDF Document Page Simulation Container
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            contentAlignment = Alignment.TopCenter
        ) {
            Surface(
                color = Color.White,
                shape = RoundedCornerShape(8.dp),
                shadowElevation = 8.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                LazyColumn(
                    contentPadding = PaddingValues(24.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    item {
                        Text(
                            text = "জাতীয় শিক্ষাক্রম ও পাঠ্যপুস্তক বোর্ড (NCTB)",
                            fontSize = (12 * zoomScale).sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.Gray
                        )
                        Text(
                            text = "অধ্যায় ${chapter.chapterNumber}: ${chapter.titleBangla}",
                            fontSize = (18 * zoomScale).sp,
                            fontWeight = FontWeight.Bold,
                            color = RoyalBluePrimary
                        )
                        Divider(modifier = Modifier.padding(vertical = 8.dp))
                    }

                    item {
                        Text(
                            text = "১.১ মূল আলোচনা ও পরিচিতি",
                            fontSize = (15 * zoomScale).sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = chapter.summary,
                            fontSize = (13 * zoomScale).sp,
                            lineHeight = (20 * zoomScale).sp,
                            color = Color.DarkGray
                        )
                    }

                    item {
                        Text(
                            text = "১.২ গুরুত্বপূর্ণ তথ্যসূচি (Short Notes)",
                            fontSize = (15 * zoomScale).sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        chapter.shortNotes.forEach { note ->
                            Text(
                                text = "• $note",
                                fontSize = (12 * zoomScale).sp,
                                lineHeight = (18 * zoomScale).sp,
                                modifier = Modifier.padding(bottom = 6.dp)
                            )
                        }
                    }

                    item {
                        Text(
                            text = "১.৩ সূত্র ও গাণিতিক প্রয়োগ",
                            fontSize = (15 * zoomScale).sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        chapter.formulas.forEach { formula ->
                            Surface(
                                color = Color(0xFFE3F2FD),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                            ) {
                                Text(
                                    text = formula,
                                    fontSize = (13 * zoomScale).sp,
                                    fontWeight = FontWeight.Bold,
                                    color = RoyalBluePrimary,
                                    modifier = Modifier.padding(8.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
