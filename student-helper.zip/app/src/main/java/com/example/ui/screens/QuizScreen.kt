package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Leaderboard
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.nctb.McqQuestion
import com.example.data.nctb.NctbChapter
import com.example.data.nctb.NctbContentRepository
import com.example.ui.QuizState
import com.example.ui.theme.GoldStar
import com.example.ui.theme.RoyalBluePrimary
import com.example.ui.theme.SuccessGreen

@Composable
fun QuizScreen(
    quizState: QuizState,
    selectedClassId: String,
    onSelectOption: (Int) -> Unit,
    onSubmitAnswer: () -> Unit,
    onRestartQuiz: (NctbChapter) -> Unit,
    modifier: Modifier = Modifier
) {
    var quizModeTab by remember { mutableStateOf(0) } // 0: MCQ কুইজ, 1: সৃজনশীল (CQ), 2: লিডারবোর্ড

    val defaultChapter = NctbContentRepository.allClasses
        .find { it.id == selectedClassId }?.subjects?.firstOrNull()?.chapters?.firstOrNull()
        ?: NctbContentRepository.allClasses.first().subjects.first().chapters.first()

    val activeChapter = quizState.activeChapter ?: defaultChapter
    val questions = if (quizState.questions.isNotEmpty()) quizState.questions else activeChapter.mcqQuestions

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("quiz_screen")
    ) {
        // Quiz Mode Header Tabs
        ScrollableTabRow(
            selectedTabIndex = quizModeTab,
            edgePadding = 16.dp,
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            Tab(selected = quizModeTab == 0, onClick = { quizModeTab = 0 }) {
                Text("এমসিকিউ প্র্যাকটিস", modifier = Modifier.padding(14.dp), fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
            Tab(selected = quizModeTab == 1, onClick = { quizModeTab = 1 }) {
                Text("সৃজনশীল প্রশ্ন (CQ)", modifier = Modifier.padding(14.dp), fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
            Tab(selected = quizModeTab == 2, onClick = { quizModeTab = 2 }) {
                Text("লিডারবোর্ড (Rank)", modifier = Modifier.padding(14.dp), fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
        }

        when (quizModeTab) {
            0 -> McqQuizSection(
                quizState = quizState,
                activeChapter = activeChapter,
                questions = questions,
                onSelectOption = onSelectOption,
                onSubmitAnswer = onSubmitAnswer,
                onRestartQuiz = { onRestartQuiz(activeChapter) }
            )
            1 -> CreativeQuestionsSection(chapter = activeChapter)
            2 -> LeaderboardSection()
        }
    }
}

@Composable
fun McqQuizSection(
    quizState: QuizState,
    activeChapter: NctbChapter,
    questions: List<McqQuestion>,
    onSelectOption: (Int) -> Unit,
    onSubmitAnswer: () -> Unit,
    onRestartQuiz: () -> Unit
) {
    if (questions.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("এই অধ্যায়ের জন্য এমসিকিউ প্রস্তুত করা হচ্ছে...", fontSize = 14.sp)
        }
        return
    }

    if (quizState.isFinished) {
        // Quiz Finished Score Summary
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                ElevatedCard(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.EmojiEvents,
                            contentDescription = "Trophy",
                            tint = GoldStar,
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "অভিনন্দন! কুইজ সম্পন্ন হয়েছে 🎉",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${activeChapter.titleBangla}",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                        )
                        Spacer(modifier = Modifier.height(16.dp))

                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "আপনার স্কোর",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium
                                )
                                Text(
                                    text = "${quizState.score} / ${questions.size}",
                                    fontSize = 32.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = RoyalBluePrimary
                                )
                                Text(
                                    text = "সঠিকতার হার: ${(quizState.score.toFloat() / questions.size * 100).toInt()}%",
                                    fontSize = 12.sp,
                                    color = SuccessGreen,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        Button(
                            onClick = onRestartQuiz,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Replay, contentDescription = "Retry")
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("পুনরায় চেষ্টা করুন")
                        }
                    }
                }
            }

            // Wrong Answers Review
            if (quizState.wrongAnswersList.isNotEmpty()) {
                item {
                    Text(
                        text = "ভুল উত্তরগুলোর পর্যালোচনামূল ব্যাখ্যা:",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Red
                    )
                }

                items(quizState.wrongAnswersList) { (q, chosen) ->
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.3f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(text = "প্রশ্ন: ${q.question}", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(text = "আপনার উত্তর: ${q.options.getOrNull(chosen) ?: ""}", fontSize = 12.sp, color = Color.Red)
                            Text(text = "সঠিক উত্তর: ${q.options[q.correctOptionIndex]}", fontSize = 12.sp, color = SuccessGreen, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(text = "💡 ব্যাখ্যা: ${q.explanation}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
                        }
                    }
                }
            }
        }
    } else {
        // Active Question View
        val currentQ = questions.getOrNull(quizState.currentIndex) ?: questions.first()

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // Progress
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "প্রশ্ন ${quizState.currentIndex + 1} / ${questions.size}",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "অধ্যায়: ${activeChapter.titleBangla}",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = { (quizState.currentIndex + 1).toFloat() / questions.size },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp))
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Question Card
            ElevatedCard(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = currentQ.question,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        lineHeight = 24.sp
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    val prefixes = listOf("ক", "খ", "গ", "ঘ")
                    currentQ.options.forEachIndexed { index, optionText ->
                        val isSelected = quizState.selectedOptionIndex == index
                        val optionColor = if (isSelected) RoyalBluePrimary else MaterialTheme.colorScheme.surface

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surface,
                            border = androidx.compose.foundation.BorderStroke(
                                width = if (isSelected) 2.dp else 1.dp,
                                color = if (isSelected) RoyalBluePrimary else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp)
                                .clickable { onSelectOption(index) }
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    shape = CircleShape,
                                    color = if (isSelected) RoyalBluePrimary else MaterialTheme.colorScheme.outline.copy(alpha = 0.2f),
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text(
                                            text = prefixes.getOrElse(index) { "" },
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = optionText,
                                    fontSize = 14.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Button(
                        onClick = onSubmitAnswer,
                        enabled = quizState.selectedOptionIndex != null,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = if (quizState.currentIndex + 1 < questions.size) "পরবর্তী প্রশ্ন" else "কুইজ জমা দিন",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun CreativeQuestionsSection(chapter: NctbChapter) {
    if (chapter.creativeQuestions.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
            Text("এই অধ্যায়ের সৃজনশীল প্রশ্ন শীঘ্রই আপডেট করা হবে।", fontSize = 14.sp)
        }
        return
    }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        items(chapter.creativeQuestions) { cq ->
            ElevatedCard(
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = "উদ্দীপক: ${cq.stem}",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("ক) ${cq.questionA}", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text("খ) ${cq.questionB}", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text("গ) ${cq.questionC}", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text("ঘ) ${cq.questionD}", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("💡 সংকেত: ${cq.answerHint}", fontSize = 12.sp, color = SuccessGreen, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun LeaderboardSection() {
    val dummyLeaderboard = listOf(
        Triple("১. মো: আরিফ হোসেন", "ঢাকা কলেজিয়েট স্কুল", "৯৮০ পয়েন্ট"),
        Triple("২. সাদিয়া আফরিন", "ভিকারুননিসা নূন স্কুল", "৯৫০ পয়েন্ট"),
        Triple("৩. তানভীর আহমেদ (আপনি)", "আইডিয়াল স্কুল এন্ড কলেজ", "৯২০ পয়েন্ট"),
        Triple("৪. ফাহিম রহমান", "রাজশাহী জিলা স্কুল", "৮৯০ পয়েন্ট"),
        Triple("৫. সুমাইয়া ইসলাম", "চট্টগ্রাম সরকারি বালিকা বিদ্যালয়", "৮৭০ পয়েন্ট")
    )

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.Leaderboard, contentDescription = "Rank", tint = RoyalBluePrimary)
                Spacer(modifier = Modifier.width(8.dp))
                Text("জাতীয় সাপ্তাহিক মেধা তালিকা (Leaderboard)", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        }

        items(dummyLeaderboard) { item ->
            ElevatedCard(shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(item.first, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Text(item.second, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                    }
                    Text(item.third, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = RoyalBluePrimary)
                }
            }
        }
    }
}
