package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.GeminiStudyService
import com.example.data.AppDatabase
import com.example.data.SavedContentEntity
import com.example.data.StudentRepository
import com.example.data.UserProfileEntity
import com.example.data.nctb.McqQuestion
import com.example.data.nctb.NctbChapter
import com.example.data.nctb.NctbContentRepository
import com.example.data.nctb.NctbSubject
import com.example.data.nctb.VideoLesson
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch

enum class MainTab {
    HOME, ACADEMIC, AI_ASSISTANT, QUIZ, OFFLINE, PROFILE
}

data class QuizState(
    val activeChapter: NctbChapter? = null,
    val questions: List<McqQuestion> = emptyList(),
    val currentIndex: Int = 0,
    val selectedOptionIndex: Int? = null,
    val score: Int = 0,
    val isFinished: Boolean = false,
    val wrongAnswersList: List<Pair<McqQuestion, Int>> = emptyList()
)

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: StudentRepository

    init {
        val dao = AppDatabase.getDatabase(application).studentDao()
        repository = StudentRepository(dao)

        viewModelScope.launch {
            val user = dao.getUserProfileOnce()
            if (user == null) {
                dao.insertOrUpdateUserProfile(UserProfileEntity())
            }
        }
    }

    val userProfile = repository.userProfile
    val studyHistory = repository.studyHistory
    val savedContent = repository.savedContent
    val quizResults = repository.quizResults

    private val _currentTab = MutableStateFlow(MainTab.HOME)
    val currentTab: StateFlow<MainTab> = _currentTab.asStateFlow()

    private val _selectedClassId = MutableStateFlow("class10")
    val selectedClassId: StateFlow<String> = _selectedClassId.asStateFlow()

    private val _selectedSubject = MutableStateFlow<NctbSubject?>(null)
    val selectedSubject: StateFlow<NctbSubject?> = _selectedSubject.asStateFlow()

    private val _selectedChapter = MutableStateFlow<NctbChapter?>(null)
    val selectedChapter: StateFlow<NctbChapter?> = _selectedChapter.asStateFlow()

    private val _selectedVideo = MutableStateFlow<VideoLesson?>(null)
    val selectedVideo: StateFlow<VideoLesson?> = _selectedVideo.asStateFlow()

    private val _pdfReaderChapter = MutableStateFlow<NctbChapter?>(null)
    val pdfReaderChapter: StateFlow<NctbChapter?> = _pdfReaderChapter.asStateFlow()

    // AI Assistant State
    private val _aiPrompt = MutableStateFlow("")
    val aiPrompt: StateFlow<String> = _aiPrompt.asStateFlow()

    private val _aiTaskType = MutableStateFlow("Q&A") // Q&A, NOTES, SUMMARY, FORMULA, MCQ
    val aiTaskType: StateFlow<String> = _aiTaskType.asStateFlow()

    private val _aiResponse = MutableStateFlow("")
    val aiResponse: StateFlow<String> = _aiResponse.asStateFlow()

    private val _isAiLoading = MutableStateFlow(false)
    val isAiLoading: StateFlow<Boolean> = _isAiLoading.asStateFlow()

    // Quiz State
    private val _quizState = MutableStateFlow(QuizState())
    val quizState: StateFlow<QuizState> = _quizState.asStateFlow()

    // Admin & Settings modals
    private val _showAdminPanel = MutableStateFlow(false)
    val showAdminPanel: StateFlow<Boolean> = _showAdminPanel.asStateFlow()

    private val _showSettings = MutableStateFlow(false)
    val showSettings: StateFlow<Boolean> = _showSettings.asStateFlow()

    private val _showAbout = MutableStateFlow(false)
    val showAbout: StateFlow<Boolean> = _showAbout.asStateFlow()

    fun selectTab(tab: MainTab) {
        _currentTab.value = tab
    }

    fun setSelectedClass(classId: String) {
        _selectedClassId.value = classId
        val current = NctbContentRepository.allClasses.find { it.id == classId }
        _selectedSubject.value = current?.subjects?.firstOrNull()
        _selectedChapter.value = null
    }

    fun selectSubject(subject: NctbSubject) {
        _selectedSubject.value = subject
        _selectedChapter.value = null
        _currentTab.value = MainTab.ACADEMIC
    }

    fun selectChapter(chapter: NctbChapter) {
        _selectedChapter.value = chapter
        viewModelScope.launch {
            repository.addStudyHistory(
                title = chapter.titleBangla,
                type = "NOTE",
                subject = _selectedSubject.value?.nameBangla ?: "NCTB",
                chapter = "অধ্যায় ${chapter.chapterNumber}"
            )
        }
    }

    fun openVideoLesson(video: VideoLesson, chapter: NctbChapter) {
        _selectedVideo.value = video
        viewModelScope.launch {
            repository.addStudyHistory(
                title = video.title,
                type = "VIDEO",
                subject = _selectedSubject.value?.nameBangla ?: "NCTB",
                chapter = "অধ্যায় ${chapter.chapterNumber}"
            )
        }
    }

    fun closeVideoLesson() {
        _selectedVideo.value = null
    }

    fun openPdfReader(chapter: NctbChapter) {
        _pdfReaderChapter.value = chapter
        viewModelScope.launch {
            repository.addStudyHistory(
                title = "${chapter.titleBangla} (PDF)",
                type = "PDF",
                subject = _selectedSubject.value?.nameBangla ?: "NCTB",
                chapter = "অধ্যায় ${chapter.chapterNumber}"
            )
        }
    }

    fun closePdfReader() {
        _pdfReaderChapter.value = null
    }

    fun saveContentToOffline(chapter: NctbChapter, type: String = "NOTE") {
        viewModelScope.launch {
            val saved = SavedContentEntity(
                id = "${chapter.id}_$type",
                title = chapter.titleBangla,
                contentType = type,
                subject = _selectedSubject.value?.nameBangla ?: "NCTB",
                classLevel = _selectedClassId.value,
                contentData = chapter.summary
            )
            repository.saveOrBookmarkItem(saved)
        }
    }

    fun removeSavedItem(id: String) {
        viewModelScope.launch {
            repository.removeSavedItem(id)
        }
    }

    fun setAiPrompt(prompt: String) {
        _aiPrompt.value = prompt
    }

    fun setAiTaskType(type: String) {
        _aiTaskType.value = type
    }

    fun sendAiRequest() {
        val prompt = _aiPrompt.value.trim()
        if (prompt.isEmpty()) return

        _isAiLoading.value = true
        _aiResponse.value = ""

        viewModelScope.launch {
            val result = GeminiStudyService.generateStudyResponse(prompt, _aiTaskType.value)
            _aiResponse.value = result
            _isAiLoading.value = false
        }
    }

    fun startQuiz(chapter: NctbChapter) {
        val questions = chapter.mcqQuestions
        _quizState.value = QuizState(
            activeChapter = chapter,
            questions = questions,
            currentIndex = 0,
            score = 0,
            isFinished = false,
            wrongAnswersList = emptyList()
        )
        _currentTab.value = MainTab.QUIZ
    }

    fun selectQuizOption(optionIndex: Int) {
        _quizState.value = _quizState.value.copy(selectedOptionIndex = optionIndex)
    }

    fun submitQuizAnswer() {
        val state = _quizState.value
        val currentQ = state.questions.getOrNull(state.currentIndex) ?: return
        val chosen = state.selectedOptionIndex ?: return

        val isCorrect = chosen == currentQ.correctOptionIndex
        val newScore = if (isCorrect) state.score + 1 else state.score
        val newWrong = if (!isCorrect) state.wrongAnswersList + (currentQ to chosen) else state.wrongAnswersList

        if (state.currentIndex + 1 < state.questions.size) {
            _quizState.value = state.copy(
                currentIndex = state.currentIndex + 1,
                selectedOptionIndex = null,
                score = newScore,
                wrongAnswersList = newWrong
            )
        } else {
            _quizState.value = state.copy(
                score = newScore,
                isFinished = true,
                wrongAnswersList = newWrong
            )
            viewModelScope.launch {
                val chapter = state.activeChapter
                repository.recordQuizResult(
                    title = chapter?.titleBangla ?: "MCQ Quiz",
                    subject = _selectedSubject.value?.nameBangla ?: "NCTB",
                    score = newScore,
                    total = state.questions.size,
                    wrongSummary = "${newWrong.size} wrong answers"
                )
            }
        }
    }

    fun toggleAdminPanel(show: Boolean) {
        _showAdminPanel.value = show
    }

    fun toggleSettings(show: Boolean) {
        _showSettings.value = show
    }

    fun toggleAbout(show: Boolean) {
        _showAbout.value = show
    }

    fun updateProfile(name: String, email: String, classLevel: String) {
        viewModelScope.launch {
            val current = userProfile.firstOrNull() ?: UserProfileEntity()
            val updated = current.copy(
                name = name,
                email = email,
                selectedClass = classLevel
            )
            repository.saveUserProfile(updated)
            _selectedClassId.value = if (classLevel.contains("10")) "class10" else if (classLevel.contains("9")) "class9" else "class8"
        }
    }
}
