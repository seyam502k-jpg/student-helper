package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val RoyalBluePrimary = Color(0xFF0D47A1)
val VibrantBlueSecondary = Color(0xFF1976D2)
val SkyBlueAccent = Color(0xFF0288D1)
val SoftBlueBackground = Color(0xFFF4F7FC)
val SurfaceWhite = Color(0xFFFFFFFF)

val DarkPrimary = Color(0xFF90CAF9)
val DarkSecondary = Color(0xFF64B5F6)
val DarkBackground = Color(0xFF0B132B)
val DarkSurface = Color(0xFF1C2541)

val SuccessGreen = Color(0xFF2E7D32)
val WarningOrange = Color(0xFFED6C02)
val GoldStar = Color(0xFFFFB300)

