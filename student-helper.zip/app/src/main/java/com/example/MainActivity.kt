package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.MainTab
import com.example.ui.MainViewModel
import com.example.ui.components.BottomNavBar
import com.example.ui.components.TopNavBar
import com.example.ui.screens.AcademicScreen
import com.example.ui.screens.AdminModal
import com.example.ui.screens.AiAssistantScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.OfflineLibraryScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.QuizScreen
import com.example.ui.screens.SettingsModal
import com.example.ui.theme.StudentHelperTheme

class MainActivity : ComponentActivity() {
    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
            val userProfile by viewModel.userProfile.collectAsStateWithLifecycle(initialValue = null)
            val selectedClassId by viewModel.selectedClassId.collectAsStateWithLifecycle()
            val selectedSubject by viewModel.selectedSubject.collectAsStateWithLifecycle()
            val selectedChapter by viewModel.selectedChapter.collectAsStateWithLifecycle()
            val selectedVideo by viewModel.selectedVideo.collectAsStateWithLifecycle()
            val pdfChapter by viewModel.pdfReaderChapter.collectAsStateWithLifecycle()

            val aiPrompt by viewModel.aiPrompt.collectAsStateWithLifecycle()
            val aiTaskType by viewModel.aiTaskType.collectAsStateWithLifecycle()
            val aiResponse by viewModel.aiResponse.collectAsStateWithLifecycle()
            val isAiLoading by viewModel.isAiLoading.collectAsStateWithLifecycle()

            val quizState by viewModel.quizState.collectAsStateWithLifecycle()
            val savedContent by viewModel.savedContent.collectAsStateWithLifecycle(initialValue = emptyList())
            val studyHistory by viewModel.studyHistory.collectAsStateWithLifecycle(initialValue = emptyList())

            val showAdmin by viewModel.showAdminPanel.collectAsStateWithLifecycle()
            val showSettings by viewModel.showSettings.collectAsStateWithLifecycle()

            var isDarkMode by remember { mutableStateOf(userProfile?.isDarkMode ?: false) }

            StudentHelperTheme(darkTheme = isDarkMode) {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    topBar = {
                        TopNavBar(
                            userProfile = userProfile,
                            selectedClassId = selectedClassId,
                            onClassSelected = { viewModel.setSelectedClass(it) },
                            onOpenAdmin = { viewModel.toggleAdminPanel(true) },
                            onOpenSettings = { viewModel.toggleSettings(true) },
                            onOpenProfile = { viewModel.selectTab(MainTab.PROFILE) }
                        )
                    },
                    bottomBar = {
                        BottomNavBar(
                            selectedTab = currentTab,
                            onTabSelected = { viewModel.selectTab(it) }
                        )
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        when (currentTab) {
                            MainTab.HOME -> HomeScreen(
                                userProfile = userProfile,
                                selectedClassId = selectedClassId,
                                onSelectTab = { viewModel.selectTab(it) },
                                onSelectClass = { viewModel.setSelectedClass(it) }
                            )

                            MainTab.ACADEMIC -> AcademicScreen(
                                selectedClassId = selectedClassId,
                                selectedSubject = selectedSubject,
                                selectedChapter = selectedChapter,
                                selectedVideo = selectedVideo,
                                pdfChapter = pdfChapter,
                                onSelectSubject = { viewModel.selectSubject(it) },
                                onSelectChapter = { viewModel.selectChapter(it) },
                                onOpenVideo = { video, ch -> viewModel.openVideoLesson(video, ch) },
                                onCloseVideo = { viewModel.closeVideoLesson() },
                                onOpenPdf = { ch -> viewModel.openPdfReader(ch) },
                                onClosePdf = { viewModel.closePdfReader() },
                                onStartQuiz = { ch -> viewModel.startQuiz(ch) },
                                onSaveDownload = { ch -> viewModel.saveContentToOffline(ch) }
                            )

                            MainTab.AI_ASSISTANT -> AiAssistantScreen(
                                prompt = aiPrompt,
                                taskType = aiTaskType,
                                response = aiResponse,
                                isLoading = isAiLoading,
                                onPromptChange = { viewModel.setAiPrompt(it) },
                                onTaskTypeChange = { viewModel.setAiTaskType(it) },
                                onSubmit = { viewModel.sendAiRequest() }
                            )

                            MainTab.QUIZ -> QuizScreen(
                                quizState = quizState,
                                selectedClassId = selectedClassId,
                                onSelectOption = { viewModel.selectQuizOption(it) },
                                onSubmitAnswer = { viewModel.submitQuizAnswer() },
                                onRestartQuiz = { ch -> viewModel.startQuiz(ch) }
                            )

                            MainTab.OFFLINE -> OfflineLibraryScreen(
                                savedContent = savedContent,
                                onRemoveItem = { viewModel.removeSavedItem(it) }
                            )

                            MainTab.PROFILE -> ProfileScreen(
                                userProfile = userProfile,
                                studyHistory = studyHistory,
                                onUpdateProfile = { name, email, cls -> viewModel.updateProfile(name, email, cls) }
                            )
                        }

                        if (showAdmin) {
                            AdminModal(
                                onDismiss = { viewModel.toggleAdminPanel(false) }
                            )
                        }

                        if (showSettings) {
                            SettingsModal(
                                isDarkMode = isDarkMode,
                                onToggleDarkMode = { isDarkMode = it },
                                onDismiss = { viewModel.toggleSettings(false) }
                            )
                        }
                    }
                }
            }
        }
    }
}
