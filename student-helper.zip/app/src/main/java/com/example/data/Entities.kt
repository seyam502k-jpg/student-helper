package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_profile")
data class UserProfileEntity(
    @PrimaryKey val id: Int = 1,
    val name: String = "Md. Tanvir Ahmed",
    val email: String = "tanvir.student@gmail.com",
    val selectedClass: String = "Class 10",
    val streakDays: Int = 7,
    val studyTimeMinutes: Int = 210,
    val dailyGoalMinutes: Int = 60,
    val completedChaptersCount: Int = 14,
    val quizzesTakenCount: Int = 12,
    val isDarkMode: Boolean = false,
    val language: String = "Bangla" // "Bangla" or "English"
)

@Entity(tableName = "study_history")
data class StudyHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val type: String, // "VIDEO", "NOTE", "QUIZ"
    val subject: String,
    val chapterName: String,
    val timestamp: Long = System.currentTimeMillis(),
    val progressPercent: Float = 1.0f
)

@Entity(tableName = "saved_content")
data class SavedContentEntity(
    @PrimaryKey val id: String,
    val title: String,
    val contentType: String, // "PDF", "NOTE", "VIDEO"
    val subject: String,
    val classLevel: String,
    val contentData: String,
    val isDownloaded: Boolean = true,
    val isFavorite: Boolean = true,
    val dateSaved: Long = System.currentTimeMillis()
)

@Entity(tableName = "quiz_results")
data class QuizResultEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val quizTitle: String,
    val subject: String,
    val score: Int,
    val total: Int,
    val timestamp: Long = System.currentTimeMillis(),
    val wrongAnswersSummary: String = ""
)
