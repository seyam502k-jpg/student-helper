package com.example.data

import kotlinx.coroutines.flow.Flow

class StudentRepository(private val dao: StudentDao) {
    val userProfile: Flow<UserProfileEntity?> = dao.getUserProfile()
    val studyHistory: Flow<List<StudyHistoryEntity>> = dao.getStudyHistory()
    val savedContent: Flow<List<SavedContentEntity>> = dao.getSavedContent()
    val quizResults: Flow<List<QuizResultEntity>> = dao.getQuizResults()

    suspend fun saveUserProfile(profile: UserProfileEntity) {
        dao.insertOrUpdateUserProfile(profile)
    }

    suspend fun addStudyHistory(title: String, type: String, subject: String, chapter: String, progress: Float = 1.0f) {
        val history = StudyHistoryEntity(
            title = title,
            type = type,
            subject = subject,
            chapterName = chapter,
            progressPercent = progress
        )
        dao.insertHistory(history)
    }

    suspend fun saveOrBookmarkItem(item: SavedContentEntity) {
        dao.saveContent(item)
    }

    suspend fun removeSavedItem(id: String) {
        dao.deleteSavedContent(id)
    }

    suspend fun recordQuizResult(title: String, subject: String, score: Int, total: Int, wrongSummary: String) {
        val result = QuizResultEntity(
            quizTitle = title,
            subject = subject,
            score = score,
            total = total,
            wrongAnswersSummary = wrongSummary
        )
        dao.insertQuizResult(result)
    }
}
