package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface StudentDao {
    @Query("SELECT * FROM user_profile WHERE id = 1")
    fun getUserProfile(): Flow<UserProfileEntity?>

    @Query("SELECT * FROM user_profile WHERE id = 1")
    suspend fun getUserProfileOnce(): UserProfileEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateUserProfile(user: UserProfileEntity)

    @Query("SELECT * FROM study_history ORDER BY timestamp DESC LIMIT 20")
    fun getStudyHistory(): Flow<List<StudyHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHistory(history: StudyHistoryEntity)

    @Query("SELECT * FROM saved_content ORDER BY dateSaved DESC")
    fun getSavedContent(): Flow<List<SavedContentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveContent(content: SavedContentEntity)

    @Query("DELETE FROM saved_content WHERE id = :id")
    suspend fun deleteSavedContent(id: String)

    @Query("SELECT * FROM quiz_results ORDER BY timestamp DESC LIMIT 30")
    fun getQuizResults(): Flow<List<QuizResultEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuizResult(result: QuizResultEntity)
}
