package com.example.data.nctb

data class NctbClass(
    val id: String,
    val name: String, // e.g. "Class 10", "Class 9", "SSC"
    val subjects: List<NctbSubject>
)

data class NctbSubject(
    val id: String,
    val name: String, // e.g. "Physics", "Mathematics", "Bangla"
    val nameBangla: String, // e.g. "পদার্থবিজ্ঞান", "গণিত"
    val iconName: String,
    val chapterCount: Int,
    val chapters: List<NctbChapter>
)

data class NctbChapter(
    val id: String,
    val chapterNumber: Int,
    val title: String,
    val titleBangla: String,
    val summary: String,
    val shortNotes: List<String>,
    val formulas: List<String>,
    val boardQuestions: List<String>,
    val videoLessons: List<VideoLesson>,
    val mcqQuestions: List<McqQuestion>,
    val creativeQuestions: List<CreativeQuestion>,
    val pdfNoteUrl: String = "https://nctb.portal.gov.bd/"
)

data class VideoLesson(
    val id: String,
    val title: String,
    val teacherName: String,
    val durationMinutes: Int,
    val youtubeVideoId: String, // e.g. "dQw4w9WgXcQ" or standard tutorial IDs
    val thumbnailUrl: String = "",
    val isCompleted: Boolean = false
)

data class McqQuestion(
    val id: Int,
    val question: String,
    val options: List<String>,
    val correctOptionIndex: Int,
    val explanation: String
)

data class CreativeQuestion(
    val id: Int,
    val stem: String, // উদ্দীপক
    val questionA: String, // ক
    val questionB: String, // খ
    val questionC: String, // গ
    val questionD: String, // ঘ
    val answerHint: String
)

object NctbContentRepository {
    val allClasses = listOf(
        NctbClass(
            id = "class10",
            name = "Class 10 / SSC",
            subjects = listOf(
                NctbSubject(
                    id = "phy10",
                    name = "Physics",
                    nameBangla = "পদার্থবিজ্ঞান",
                    iconName = "science",
                    chapterCount = 14,
                    chapters = listOf(
                        NctbChapter(
                            id = "phy10_ch1",
                            chapterNumber = 1,
                            title = "Physical Quantities and Measurement",
                            titleBangla = "ভৌত রাশি এবং পরিমাপ",
                            summary = "পদার্থবিজ্ঞান বিজ্ঞানের মূল শাখা। এই অধ্যায়ে ভৌত রাশি, পরিমাপের একক, ভার্নিয়ার স্কেল, স্ক্রু গজ এবং পরিমাপের ত্রুটি সম্পর্কে আলোচনা করা হয়েছে।",
                            shortNotes = listOf(
                                "মৌলিক রাশি ৭টি: দৈর্ঘ্য, ভর, সময়, তাপমাত্রা, তড়িৎ প্রবাহ, দীপন তীব্রতা, পদার্থের পরিমাণ।",
                                "ভার্নিয়ার ধ্রুবক (VC) = s / n = প্রধান স্কেলের ক্ষুদ্রতম ১ ভাগের দৈর্ঘ্য / ভার্নিয়ার ঘরের সংখ্যা।",
                                "লঘিষ্ঠ গণন (LC) = পিচ / বৃত্তাকার স্কেলের মোট ভাগ সংখ্যা।",
                                "আপেক্ষিক ত্রুটি = (চূড়ান্ত ত্রুটি / পরিমাপকৃত মান) × ১০০%"
                            ),
                            formulas = listOf(
                                "ভার্নিয়ার ধ্রুবক: VC = s / n",
                                "পরিমাপকৃত দৈর্ঘ্য = M + (V × VC)",
                                "স্ক্রু গজের পরিমাপ = L + (C × LC)",
                                "আপেক্ষিক ত্রুটি = (|পরিমাপকৃত মান - প্রকৃত মান| / প্রকৃত মান) × ১০০%"
                            ),
                            boardQuestions = listOf(
                                "[ঢাকা বোর্ড ২০২৩] ভার্নিয়ার সমপাতন বলতে কী বোঝায়? উদ্দীপকের স্লাইড ক্যালিপার্স দিয়ে গোলকের ব্যাস নির্ণয় করো।",
                                "[চট্টগ্রাম বোর্ড ২০২২] পরিমাপের ত্রুটি কত প্রকার? যন্ত্রের যান্ত্রিক ত্রুটি পরিমাপের ফলাফলে কীভাবে প্রভাব ফেলে?"
                            ),
                            videoLessons = listOf(
                                VideoLesson(
                                    id = "v1",
                                    title = "ভৌত রাশি ও পরিমাপ - ১০০০% সহজ ব্যাখ্যা (Class 10 Physics)",
                                    teacherName = "Tanvir Sir (10 Minute School Alumnus)",
                                    durationMinutes = 22,
                                    youtubeVideoId = "3G3v3s1Kk9Q"
                                ),
                                VideoLesson(
                                    id = "v2",
                                    title = "স্লাইড ক্যালিপার্স ও স্ক্রু গজের গাণিতিক সমস্যা সমাধান",
                                    teacherName = "Ayman Sadiq",
                                    durationMinutes = 18,
                                    youtubeVideoId = "v8E8X3e1q8k"
                                )
                            ),
                            mcqQuestions = listOf(
                                McqQuestion(
                                    id = 101,
                                    question = "নিচের কোনটি মৌলিক রাশি নয়?",
                                    options = listOf("দৈর্ঘ্য", "ভর", "বল", "তাপমাত্রা"),
                                    correctOptionIndex = 2,
                                    explanation = "বল হলো লব্ধ রাশি (F = ma)। বাকি তিনটি এসআই পদ্ধতির ৭টি মৌলিক রাশির অন্তর্ভুক্ত।"
                                ),
                                McqQuestion(
                                    id = 102,
                                    question = "ভার্নিয়ার স্কেলের ২০ ঘর প্রধান স্কেলের ১৯ ঘরের সমান হলে ভার্নিয়ার ধ্রুবক কত? (s = 1 mm)",
                                    options = listOf("0.05 mm", "0.01 mm", "0.1 mm", "0.005 mm"),
                                    correctOptionIndex = 0,
                                    explanation = "VC = s / n = 1 mm / 20 = 0.05 mm।"
                                ),
                                McqQuestion(
                                    id = 103,
                                    question = "পদার্থের পরিমাণের এসআই (SI) একক কোনটি?",
                                    options = listOf("কিলোগ্রাম", "মোল", "অ্যাম্পিয়ার", "কেলভিন"),
                                    correctOptionIndex = 1,
                                    explanation = "পদার্থের পরিমাণের একক হলো মোল (mol)।"
                                )
                            ),
                            creativeQuestions = listOf(
                                CreativeQuestion(
                                    id = 201,
                                    stem = "একটি স্লাইড ক্যালিপার্স দিয়ে গোলকের ব্যাস মাপতে গিয়ে মূল স্কেল পাঠ পাওয়া গেল 4.2 cm, ভার্নিয়ার সমপাতন 6 এবং ভার্নিয়ার ধ্রুবক 0.01 cm।",
                                    questionA = "ভার্নিয়ার ধ্রুবক কাকে বলে?",
                                    questionB = "সব লব্ধ রাশিকে মৌলিক রাশিতে প্রকাশ করা যায় কেন?",
                                    questionC = "উদ্দীপকের গোলকটির ব্যাস নির্ণয় করো।",
                                    questionD = "গোলকটির আয়তন নির্ণয়ে ১০% পরিমাপের ত্রুটি থাকলে চূড়ান্ত ত্রুটি বিশ্লেষণ করো।",
                                    answerHint = "ব্যাস D = M + (V × VC) = 4.2 + (6 × 0.01) = 4.26 cm।"
                                )
                            )
                        ),
                        NctbChapter(
                            id = "phy10_ch2",
                            chapterNumber = 2,
                            title = "Motion",
                            titleBangla = "গতি (Motion)",
                            summary = "গতিবিদ্যা পদার্থবিজ্ঞানের গুরুত্বপূর্ণ শাখা। স্থিতি, গতি, দূরত্ব, সরণ, বেগ, ত্বরণ এবং গতির সমীকরণ (v = u + at, s = ut + ½at², v² = u² + 2as) এখানে বিশদভাবে ব্যাখ্যা করা হয়েছে।",
                            shortNotes = listOf(
                                "দূরত্ব স্কেলার রাশি, সরণ ভেক্টর রাশি।",
                                "সমবেগে চলমান বস্তুর ত্বরণ শূন্য (a = 0)।",
                                "পরন্ত বস্তুর ক্ষেত্রে গ্যালিলিওর ৩টি সূত্র প্রযোজ্য।",
                                "বেগ-সময় গ্রাফের ক্ষেত্রফল বস্তুর অতিক্রান্ত দূরত্ব (s) নির্দেশ করে।"
                            ),
                            formulas = listOf(
                                "v = u + at",
                                "s = ((u + v) / 2) × t",
                                "s = ut + ½at²",
                                "v² = u² + 2as",
                                "পড়ন্ত বস্তু: h = ut + ½gt²"
                            ),
                            boardQuestions = listOf(
                                "[রাজশাহী বোর্ড ২০২৩] ৫৪ কিমি/ঘণ্টা বেগে চলন্ত গাড়ি ১০ সেকেন্ডে থেমে গেল। মন্দন ও অতিক্রান্ত দূরত্ব নির্ণয় করো।",
                                "[দিনাজপুর বোর্ড ২০২২] প্রক্ষিপ্ত বস্তু বা পরন্ত বস্তুর ক্ষেত্রে গতির সমীকরণের ব্যবহার।"
                            ),
                            videoLessons = listOf(
                                VideoLesson(
                                    id = "v3",
                                    title = "গতি - সমীকরণ ও লেখচিত্রের সম্পূর্ণ মাস্টারক্লাস (SSC Motion)",
                                    teacherName = "Ratul Sir",
                                    durationMinutes = 28,
                                    youtubeVideoId = "3G3v3s1Kk9Q"
                                )
                            ),
                            mcqQuestions = listOf(
                                McqQuestion(
                                    id = 104,
                                    question = "নিচের কোনটি ভেক্টর রাশি?",
                                    options = listOf("দূরত্ব", "দ্রুতি", "সরণ", "সময়"),
                                    correctOptionIndex = 2,
                                    explanation = "সরণের নির্দিষ্ট দিক ও মান উভয়ই রয়েছে, তাই এটি ভেক্টর রাশি।"
                                ),
                                McqQuestion(
                                    id = 105,
                                    question = "54 km/h কে m/s এ রূপান্তর করলে কত হবে?",
                                    options = listOf("10 m/s", "15 m/s", "20 m/s", "25 m/s"),
                                    correctOptionIndex = 1,
                                    explanation = "54 × (1000 / 3600) = 15 m/s।"
                                )
                            ),
                            creativeQuestions = listOf(
                                CreativeQuestion(
                                    id = 202,
                                    stem = "একটি স্থির গাড়ি 2 m/s² সুষম ত্বরণে 10s চলল, এরপর সুষম বেগে 20s চলল।",
                                    questionA = "ত্বরণ কাকে বলে?",
                                    questionB = "সমবেগে চলন্ত বস্তুর ত্বরণ শূন্য কেন?",
                                    questionC = "প্রথম 10s এ গাড়িটি কত দূরত্ব অতিক্রম করবে?",
                                    questionD = "গাড়িটির মোট অতিক্রান্ত দূরত্বের লেখচিত্র অঙ্কন করে ব্যাখ্যা করো।",
                                    answerHint = "s1 = ut + ½at² = 0 + ½(2)(10)² = 100m।"
                                )
                            )
                        )
                    )
                ),
                NctbSubject(
                    id = "math10",
                    name = "Mathematics",
                    nameBangla = "গণিত",
                    iconName = "calculate",
                    chapterCount = 17,
                    chapters = listOf(
                        NctbChapter(
                            id = "math10_ch1",
                            chapterNumber = 1,
                            title = "Real Numbers",
                            titleBangla = "বাস্তব সংখ্যা (Real Numbers)",
                            summary = "স্বাভাবিক সংখ্যা, পূর্ণসংখ্যা, ভগ্নাংশ সংখ্যা, মূলদ ও অমূলদ সংখ্যার সেট এবং এদের বৈশিষ্ট্য সম্পর্কিত অধ্যায়। √2, √3, √5 অমূলদ সংখ্যা প্রমাণ পরীক্ষার জন্য অত্যন্ত গুরুত্বপূর্ণ।",
                            shortNotes = listOf(
                                "যে সংখ্যাকে p/q আকারে প্রকাশ করা যায় তা মূলদ সংখ্যা।",
                                "যে সংখ্যাকে p/q আকারে প্রকাশ করা যায় না তা অমূলদ সংখ্যা।",
                                "সকল পৌনঃপুনিক দশমিক ভগ্নাংশ মূলদ সংখ্যা।",
                                "√p অমূলদ হবে যদি p কোনো পূর্ণবর্গ সংখ্যা না হয়।"
                            ),
                            formulas = listOf(
                                "মূলদ সংখ্যা: p/q (q ≠ 0, p ও q সহমৌলিক)",
                                "পৌনঃপুনিক রূপান্তর: (সম্পূর্ণ সংখ্যা - অনাবৃত অংশ) / (পৌনঃপুনিকের জন্য ৯ ও অনাবৃতের জন্য ০)"
                            ),
                            boardQuestions = listOf(
                                "[ঢাকা বোর্ড ২০২৩] প্রমাণ করো যে √3 একটি অমূলদ সংখ্যা।",
                                "[যশোর বোর্ড ২০২২] 0.32̇16̇ কে সাধারণ ভগ্নাংশে প্রকাশ করো।"
                            ),
                            videoLessons = listOf(
                                VideoLesson(
                                    id = "v4",
                                    title = "বাস্তব সংখ্যা - অমূলদ সংখ্যা প্রমাণের টেকনিক (SSC General Math)",
                                    teacherName = "Shahriar Sir",
                                    durationMinutes = 25,
                                    youtubeVideoId = "3G3v3s1Kk9Q"
                                )
                            ),
                            mcqQuestions = listOf(
                                McqQuestion(
                                    id = 106,
                                    question = "নিচের কোনটি অমূলদ সংখ্যা?",
                                    options = listOf("√4", "√9", "√5", "0.25"),
                                    correctOptionIndex = 2,
                                    explanation = "√5 এর মান অসীম অনাবৃত দশমিক (2.23606...), তাই এটি অমূলদ সংখ্যা।"
                                )
                            ),
                            creativeQuestions = listOf()
                        )
                    )
                ),
                NctbSubject(
                    id = "bangla10",
                    name = "Bangla",
                    nameBangla = "বাংলা প্রথম পত্র",
                    iconName = "menu_book",
                    chapterCount = 20,
                    chapters = listOf(
                        NctbChapter(
                            id = "ban10_ch1",
                            chapterNumber = 1,
                            title = "Shuba (শুভা)",
                            titleBangla = "শুভা - রবীন্দ্রনাথ ঠাকুর",
                            summary = "বাণীহীন বাকপ্রতিবন্ধী কিশোরী শুভার প্রকৃতির প্রতি গভীর মমতা ও নিঃসঙ্গতার এক করুণ আখ্যান রচনা করেছেন রবীন্দ্রনাথ ঠাকুর।",
                            shortNotes = listOf(
                                "শুভার আসল নাম: সুভাষিণী।",
                                "শুভার দুই বোন: সুকেশিনী ও সুহাসিনী।",
                                "শুভার মূক বন্ধু: প্রতাপ (যে ছিপ ফেলে মাছ ধরতে ভালোবাসত)।",
                                "শুভার গোয়ালঘরের গাভী দুটির নাম: সর্বশী ও পঙ্গুলী।"
                            ),
                            formulas = listOf(),
                            boardQuestions = listOf(
                                "[কুমিল্লা বোর্ড ২০২৩] 'প্রকৃতি যেন তাহার ভাষার অভাব পূরণ করিয়া দেয়'— ব্যাখ্যা করো।",
                                "[সিলেট বোর্ড ২০২২] শুভা ও প্রতাপের সম্পর্কের স্বরূপ বর্ণনা করো।"
                            ),
                            videoLessons = listOf(
                                VideoLesson(
                                    id = "v5",
                                    title = "শুভা গল্পের সহজ অনুধাবন ও মূলভাব আলোচনা - SSC Bangla 1st Paper",
                                    teacherName = "Farhan Sakib",
                                    durationMinutes = 20,
                                    youtubeVideoId = "3G3v3s1Kk9Q"
                                )
                            ),
                            mcqQuestions = listOf(
                                McqQuestion(
                                    id = 107,
                                    question = "শুভার গোয়ালের গাভী দুটির নাম কী ছিল?",
                                    options = listOf("সর্বশী ও পঙ্গুলী", "যমুনা ও মেঘনা", "সুহাসিনী ও সুকেশিনী", "চম্পা ও চামেলী"),
                                    correctOptionIndex = 0,
                                    explanation = "শুভার আদরের দুই গাভীর নাম ছিল সর্বশী ও পঙ্গুলী।"
                                )
                            ),
                            creativeQuestions = listOf()
                        )
                    )
                ),
                NctbSubject(
                    id = "ict10",
                    name = "ICT",
                    nameBangla = "তথ্য ও যোগাযোগ প্রযুক্তি",
                    iconName = "computer",
                    chapterCount = 6,
                    chapters = listOf(
                        NctbChapter(
                            id = "ict10_ch1",
                            chapterNumber = 1,
                            title = "Information and Communication Technology and Our Bangladesh",
                            titleBangla = "তথ্য ও যোগাযোগ প্রযুক্তি এবং আমাদের বাংলাদেশ",
                            summary = "ই-লার্নিং, ই-গভর্ন্যান্স, ই-সার্ভিস, ই-কমার্স এবং ডিজিটাল বাংলাদেশের রূপকল্প সম্পর্কিত বিবরণ।",
                            shortNotes = listOf(
                                "ডিজিটাল বাংলাদেশের প্রধান ভিত্তি ৪টি: মানবসম্পদ উন্নয়ন, জনগণের সম্পৃক্ততা, সিভিল সার্ভিস এবং আইসিটি শিল্পের বিকাশ।",
                                "ই-লার্নিং: ইলেকট্রনিক লার্নিং (অনলাইন দূরশিক্ষণ)।",
                                "ই-গভর্ন্যান্স: সরকারি কর্মকাণ্ডে তথ্যপ্রযুক্তির প্রয়োগ।"
                            ),
                            formulas = listOf(),
                            boardQuestions = listOf(
                                "[ঢাকা বোর্ড ২০২৩] ডিজিটাল বাংলাদেশে ই-সার্ভিসের ভূমিকা সংক্ষেপে লেখ।"
                            ),
                            videoLessons = listOf(),
                            mcqQuestions = listOf(
                                McqQuestion(
                                    id = 108,
                                    question = "ই-লার্নিং এর পূর্ণরূপ কী?",
                                    options = listOf("Electronic Learning", "Efficient Learning", "Easy Learning", "Engineered Learning"),
                                    correctOptionIndex = 0,
                                    explanation = "E-learning stands for Electronic Learning."
                                )
                            ),
                            creativeQuestions = listOf()
                        )
                    )
                )
            )
        ),
        NctbClass(
            id = "class9",
            name = "Class 9",
            subjects = listOf(
                NctbSubject(
                    id = "chem9",
                    name = "Chemistry",
                    nameBangla = "রসায়ন",
                    iconName = "science",
                    chapterCount = 12,
                    chapters = listOf(
                        NctbChapter(
                            id = "chem9_ch1",
                            chapterNumber = 1,
                            title = "Concepts of Chemistry",
                            titleBangla = "রসায়নের ধারণা",
                            summary = "রসায়নের পরিচিতি, কাঁচ আম টক কিন্তু পাকা আম মিষ্টি কেন, এবং পরীক্ষাগারে সতর্কতামূলক চিহ্নের আলোচনা।",
                            shortNotes = listOf(
                                "রসায়নের জনক: অ্যা এন্টনি লাভয়সিয়েকে আধুনিক রসায়নের জনক বলা হয়।",
                                "আম পাকার কারণ: গ্লুকোজ ও ফ্রুক্টোজ তৈরি হওয়া।"
                            ),
                            formulas = listOf(),
                            boardQuestions = listOf(),
                            videoLessons = listOf(),
                            mcqQuestions = listOf(),
                            creativeQuestions = listOf()
                        )
                    )
                )
            )
        ),
        NctbClass(
            id = "class8",
            name = "Class 8",
            subjects = listOf(
                NctbSubject(
                    id = "sci8",
                    name = "Science",
                    nameBangla = "বিজ্ঞান",
                    iconName = "biotech",
                    chapterCount = 14,
                    chapters = listOf()
                )
            )
        ),
        NctbClass(
            id = "class7",
            name = "Class 7",
            subjects = listOf()
        ),
        NctbClass(
            id = "class6",
            name = "Class 6",
            subjects = listOf()
        )
    )
}
