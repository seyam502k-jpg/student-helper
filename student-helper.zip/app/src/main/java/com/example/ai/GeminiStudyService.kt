package com.example.ai

import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object GeminiStudyService {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent"

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    suspend fun generateStudyResponse(prompt: String, taskType: String = "Q&A"): String = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext getOfflineAiFallback(prompt, taskType)
        }

        val systemInstructionText = when (taskType) {
            "NOTES" -> "You are Student Helper AI, an expert NCTB curriculum teacher in Bangladesh. Generate comprehensive, beautifully formatted study notes in Bangla with bullet points, key concepts, formulas, and board exam tips."
            "SUMMARY" -> "You are Student Helper AI. Provide a concise, clear chapter summary in Bangla highlighting the core points for NCTB Bangladeshi students."
            "FORMULA" -> "You are Student Helper AI. List all key formulas, units, and constants for the requested topic in Bangla/English with clear explanations."
            "MCQ" -> "You are Student Helper AI. Generate 3 high-yield MCQ practice questions in Bangla with 4 options (ক, খ, গ, ঘ), correct answer, and explanation."
            else -> "You are Student Helper AI, an encouraging and expert study assistant for Bangladeshi NCTB students (Class 6 to SSC/HSC). Answer study questions clearly in Bangla/English with examples."
        }

        try {
            val rootJson = JSONObject()

            // System Instruction
            val sysPart = JSONObject().put("text", systemInstructionText)
            val sysParts = JSONArray().put(sysPart)
            val sysContent = JSONObject().put("parts", sysParts)
            rootJson.put("systemInstruction", sysContent)

            // Prompt content
            val userPart = JSONObject().put("text", prompt)
            val userParts = JSONArray().put(userPart)
            val userContent = JSONObject().put("parts", userParts)
            val contentsArray = JSONArray().put(userContent)
            rootJson.put("contents", contentsArray)

            val requestBody = rootJson.toString().toRequestBody("application/json".toMediaType())
            val httpRequest = Request.Builder()
                .url("$BASE_URL?key=$apiKey")
                .post(requestBody)
                .build()

            client.newCall(httpRequest).execute().use { response ->
                if (!response.isSuccessful) {
                    return@withContext getOfflineAiFallback(prompt, taskType)
                }
                val respBody = response.body?.string() ?: return@withContext "Empty response received."
                val jsonResp = JSONObject(respBody)
                val candidates = jsonResp.optJSONArray("candidates") ?: return@withContext getOfflineAiFallback(prompt, taskType)
                if (candidates.length() == 0) return@withContext getOfflineAiFallback(prompt, taskType)

                val firstCand = candidates.getJSONObject(0)
                val candContent = firstCand.optJSONObject("content") ?: return@withContext getOfflineAiFallback(prompt, taskType)
                val parts = candContent.optJSONArray("parts") ?: return@withContext getOfflineAiFallback(prompt, taskType)
                if (parts.length() == 0) return@withContext getOfflineAiFallback(prompt, taskType)

                val text = parts.getJSONObject(0).optString("text", "")
                return@withContext if (text.isNotBlank()) text else getOfflineAiFallback(prompt, taskType)
            }
        } catch (e: Exception) {
            return@withContext getOfflineAiFallback(prompt, taskType)
        }
    }

    private fun getOfflineAiFallback(prompt: String, taskType: String): String {
        return when (taskType) {
            "NOTES" -> """
                📚 **অধ্যায়ের সংক্ষিপ্ত নোট (AI Generated)**
                
                📌 **মূল বিষয়বস্তু ($prompt):**
                - এই বিষয়টি এনসিটিবি পাঠ্যক্রমের জন্য অত্যন্ত গুরুত্বপূর্ণ।
                - মৌলিক ধারণা এবং সূত্রের প্রয়োগ ভালোভাবে মুখস্থ করতে হবে।
                
                💡 **গুরুত্বপূর্ণ পয়েন্টসমূহ:**
                ১. প্রশ্ন ভালোভাবে পড়ে মান ও দিক নির্ধারণ করা।
                ২. বোর্ডের বিগত বছরের প্রশ্নের প্যাটার্ন অনুধাবন করা।
                ৩. উত্তরপত্রে পরিষ্কার চিত্র ও সমীকরণ উপস্থাপন করা।
                
                🎯 **পরীক্ষার টিপস:**
                এমসিকিউ ও সৃজনশীল ক-খ প্রশ্নের জন্য পাঠ্যবইয়ের প্রতিটি অধ্যায় রিডিং পড়া আবশ্যিক।
            """.trimIndent()

            "FORMULA" -> """
                📐 **গুরুত্বপূর্ণ সূত্র সমাহার ($prompt):**
                
                ১. গতির সমীকরণ: v = u + at
                ২. অতিক্রান্ত দূরত্ব: s = ut + ½at²
                ৩. শেষ বেগ: v² = u² + 2as
                ৪. বল ও ত্বরণ: F = ma
                ৫. কাজ ও শক্তি: W = Fs = mgh
                
                ⚠️ **একক ও মাত্রাসমূহ:**
                - বলের একক: নিউটন (N)
                - কাজের একক: জুল (J)
                - ত্বরণের একক: m/s²
            """.trimIndent()

            "MCQ" -> """
                📝 **প্র্যাকটিস এমসিকিউ ($prompt):**
                
                ১. নিচের কোনটি মৌলিক একক?
                   ক) নিউটন  খ) জুল  গ) কিলোগ্রাম  ঘ) ওয়াট
                   ✅ **সঠিক উত্তর:** গ) কিলোগ্রাম
                   💡 **ব্যাখ্যা:** কিলোগ্রাম ভরের মৌলিক একক।
                
                ২. সমবেগে চলন্ত বস্তুর ত্বরণ কত?
                   ক) ৯.৮ m/s²  খ) শূন্য  গ) ৯৮ m/s²  ঘ) অসীম
                   ✅ **সঠিক উত্তর:** খ) শূন্য
            """.trimIndent()

            else -> """
                🤖 **স্টুডেন্ট হেল্পার AI উত্তর:**
                
                আপনার প্রশ্ন: "$prompt"
                
                উত্তর: এনসিটিবি পাঠ্যক্রম অনুযায়ী বিষয়টির মূল ধারণা হলো পাঠ্যবইয়ের সংজ্ঞাসমূহ আয়ত্ত করা এবং গাণিতিক সমস্যার ক্ষেত্রে সূত্র প্রয়োগ করা। 
                
                আপনার পড়াশোনার যেকোনো সহায়তায় প্রতিদিন স্টুডেন্ট হেল্পার AI ব্যবহার করুন!
            """.trimIndent()
        }
    }
}
